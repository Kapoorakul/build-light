import json
import sys
import urllib2
import ssl
import time
import requests
from requests.packages.urllib3.exceptions import InsecureRequestWarning
from jenkinsapi.jenkins import Jenkins
from pprint import pprint
import threading

requests.packages.urllib3.disable_warnings(InsecureRequestWarning)
ctx = ssl.create_default_context()
ctx.check_hostname = False
ctx.verify_mode = ssl.CERT_NONE

api_endpoint = 'http://10.120.18.175/api/'
bridge_user = 'bgl3VFxsl9rQcJbFZ7iqX4kdCULQlpnhIGrRtAnB'
mobius_light = '2'
erXchange_light = '3'
mobius_jenkins = 'https://jenkins.mobius.emdeon.net:443/'
erXchange_jenkins = 'http://jenkins.westlakerobotics.com:8080/'


def check_build(job_list,jenkinsUrl,ctx,light):
    COUNTER = 0
    while COUNTER<1:
      COUNTER += 1
      FLAG = 0
      print('*************************Checking Jobs******************************')
#      bridge_conn.get_light(light,'hue')
      for jobName in job_list:
          try:
             jenkinsStream   = urllib2.urlopen( jenkinsUrl + jobName + "/lastBuild/api/json", context=ctx )
             buildStatusJson = json.load( jenkinsStream )
          except urllib2.HTTPError, e:
             continue

          if buildStatusJson.has_key( "result" ):
             status=buildStatusJson["result"]
             print("[{}] build status: {}".format(jobName,status))
             if buildStatusJson["result"] != "SUCCESS" :
                requests.put(api_endpoint + bridge_user + '/lights/' + light +'/state',data=json.dumps({ "hue":0 }))
                FLAG=1
             else:
                pass

      if FLAG==0:
         print('*********************ALL JOBS PASSED***********************************')
         requests.put(api_endpoint + bridge_user + '/lights/' + light +'/state',data=json.dumps({ "hue":46920 }))

      for i in range(10,0,-1):
          print 'tasks done, now sleeping for %d seconds\r' % i,
          sys.stdout.flush()
          time.sleep(1)

def jenkins_jobs(jenkins_url):

    jenkins_conn = Jenkins(jenkins_url,ssl_verify=False)
#    pprint(jenkins_conn.keys())
    return jenkins_conn.keys()


def main():


    requests.put(api_endpoint + bridge_user + '/lights/' + mobius_light +'/state',data=json.dumps({ "hue":46920 }))
    requests.put(api_endpoint + bridge_user + '/lights/' + erXchange_light +'/state',data=json.dumps({ "hue":46920 }))

    mobius_jobs = jenkins_jobs(mobius_jenkins)
    erXchange_jobs = jenkins_jobs(erXchange_jenkins)

    jenkinsUrl = mobius_jenkins + 'job/'
    erXchangeURL = erXchange_jenkins + 'job/'

    print('Creating Thread')
    mobius_thread = threading.Thread(target=check_build, args=(mobius_jobs,jenkinsUrl,ctx,mobius_light))
    mobius_thread.start()
    erXchange_thread = threading.Thread(target=check_build,args=(erXchange_jobs,erXchangeURL,ctx,erXchange_light))
    erXchange_thread.start()



if __name__ == "__main__":
        main()

